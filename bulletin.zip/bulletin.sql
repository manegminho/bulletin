﻿# Host: localhost  (Version 5.7.23)
# Date: 2019-02-13 22:05:57
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "guestbook"
#

DROP TABLE IF EXISTS `guestbook`;
CREATE TABLE `guestbook` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(10) NOT NULL DEFAULT '',
  `passwd` varchar(10) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `regist_day` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "guestbook"
#


#
# Structure for table "list"
#

DROP TABLE IF EXISTS `list`;
CREATE TABLE `list` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `passwd` varchar(20) NOT NULL DEFAULT '',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `regist_day` varchar(20) NOT NULL DEFAULT '',
  `hit` int(11) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# Data for table "list"
#

INSERT INTO `list` VALUES (1,'민호','aodalsgh1','1','11111','2018-02-10',2,NULL),(3,'2','2','fdasfasdf','asdfasdfsfadgsfadfds','2019-02-11 10:19:30',9,NULL),(4,'123123','1','1','1231231232                ','2019-02-12 17:10:07',21,NULL),(5,'root1','1','마님3','                      12312123  \r\ndfdsafasdfsdaf                       ','2019-02-12 18:00:39',14,NULL),(6,'dark','1','dsafdasf','fdafadsfasdfsda','2019-02-12 21:05:43',385,NULL);
